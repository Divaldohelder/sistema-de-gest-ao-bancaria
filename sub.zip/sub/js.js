let servicos = [
    {
        DSTV: (plano) => {
            if (contas.valor < 20000 || contas.valor > 0) {
                if (plano == "Fácil") {
                    return contas.valor - 2.950
                }
                if (plano == "Familía") {
                    return contas.valor - 4.050
                }
                if (plano == "Grande") {
                    return contas.valor - 7.600
                }
                if (plano == "Grande+") {
                    return contas.valor - 12.050
                }
                if (plano == "Bué") {
                    return contas.valor - 15.850
                }
            }
            else if (contas.valor > 20000) {
                if (plano == "Mega") {
                    return contas.valor - 22.000
                }
            }

        },
    }
]
let indece=0
let nomes = []
let contas = []
const tabela = document.querySelector("tbody")
document.getElementById("add").addEventListener("change", () => {
    contas.push(nvCliente(document.querySelector("input").value, random(), random(), 20000))
    console.table(contas)
    tabela.innerHTML += "<tr><td>" + contas[indece].nome + "</td><td>" + contas[indece].nConta + "</td><td>" + contas[indece].pass + "</td><td>" + contas[indece].valor + "</td></tr>"
    indece++

})


function nvCliente(nome, nConta, pass, valor) {
    return { nome: nome, nConta: nConta, pass: pass, valor: valor }
}

function random() {
    let random = Math.floor(Math.random() * 1000).toString()
    if (random.length == 3) {
        return Number(random + 5)
    }
    else if (random.length == 2) {
        return Number(random + 55)
    }
    else if (random.length == 1) {
        return Number(random + 555)
    }

}

